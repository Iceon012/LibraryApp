<?php
	//config.php
	include 'config.php';

	$postdata= file_get_contents("php://input");
	$request = json_decode($postdata);

	$query = "INSERT INTO logs (id_num,logName,log_date,log_time,log_purpose) values('$request->studID', '$request->studName', '$request->datelog', '$request->timelog', '$request->purposelog')";

	$result = $conn->query($query);

	if($result){
		echo json_encode("OK");
	}
?>