<?php
	//config.php
	include 'config.php';

	$postdata= file_get_contents("php://input");
	$request = json_decode($postdata);

	$query = "INSERT INTO logs (log_id, id_num, log_date, log_time, log_purpose) values('$request->studID', '$request->datelog', '$request->timelog', '$request->logpurpose')";

	$result = $conn->query($query);

	if($result){
		echo json_encode("OK");
	}
?>