<?php
	//login.php
	include 'config.php';
	
	$postdata= file_get_contents("php://input");
	$request = json_decode($postdata);
	
	$q = "SELECT id_num, stud_id, concat(lname, ', ', fname, ' ', middle, '.') as Name, course, email FROM lib_users WHERE  stud_id='$request->studID'";
	$result = $conn->query($q);

	if($result){
		if($result-> num_rows != 0){
	 		$row = $result->fetch_object();
			$userid = $row->id_num;
		}
		else {
			$userid = 0;
		}
	}

	echo json_encode($userid);
?>