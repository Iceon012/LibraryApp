<?php
	//config.php
	include 'config.php';

	$postdata= file_get_contents("php://input");
	$request = json_decode($postdata);

	$query = "INSERT INTO lib_users (stud_id,lname,fname,middle,course,bdate,time,email,password) values('$request->idnum','$request->lastname','$request->firstname',
             '$request->middlename','$request->course','$request->date','$request->time','$request->email',sha1('$request->password'))";

	$result = $conn->query($query);

	if($result){
		echo json_encode("OK");
	}
?>