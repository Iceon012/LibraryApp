<?php
	//config.php
	include 'config.php';

	$postdata= file_get_contents("php://input");
	$request = json_decode($postdata);

	$query = "INSERT INTO userlogin (emp_num,name,email,password) values('$request->empid','$request->empname','$request->email',sha1('$request->password'))";

	$result = $conn->query($query);

	if($result){
		echo json_encode("OK");
	}
?>