<?php 
	include 'config.php';

	$q = "SELECT id_num, stud_id, CONCAT(lname, ', ', fname, ' ', middle,'.') as Name, course FROM lib_users;";
	$result = $conn->query($q);
	
	$data = array();
	
	while($row = $result->fetch_object()){
		array_push($data,$row);
	}
	
	echo json_encode($data);
?>