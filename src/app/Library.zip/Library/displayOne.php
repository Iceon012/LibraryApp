<?php 
	include 'config.php';

	$eid = $_GET['eid'];
	
	$response = new stdClass();

	$q = "SELECT id_num, stud_id, CONCAT(lname, ', ', fname, ' ', middle,'.') as Name, course FROM lib_users where id_num = $eid";
	$result = $conn->query($q);
	
	$data = array();
	
	while($row = $result->fetch_object()){
		array_push($data,$row);
	}

    $response = $data;
	
	echo json_encode($response);
?>