<?php 
	include 'config.php';

	$q = "SELECT id_log, id_num, logName, log_date, log_time, log_purpose FROM logs order by logName;";
	$result = $conn->query($q);
	
	$data = array();
	
	while($row = $result->fetch_object()){
		array_push($data,$row);
	}
	
	echo json_encode($data);
?>